ReadMe
compasses, great circles & the loop
part 1: compass
required: sublime text, web server, ftp client

Resources:
javascript: http://www.w3schools.com/js/
device orientation: http://www.html5rocks.com/en/tutorials/device/orientation/

Example #1: Compass
This example consists of javascript files working with html and css. To try different variations, change the javascript src in index.html. For example, two options are:

A. <script type="text/javascript" src="01compass_degrees.js"></script>
B. <script type="text/javascript" src="01compass_text.js"></script>

For utilizing this example, it is best to understand basic javascript: variables, arrays, functions and conditionals

When you have tried all of the examples, create your own variant.
Possible constraints: random content, flickering content, media content, site-responsive content, content that evolves over time